x = 5 * (3 + 2)

y = "if works"

z = 3

if x > z then
    print(y)
    print("if this doesn't work, this confirms if is being called but its just a string issue")
end

if x == x then
    print("Welp if that didn't work atleast you have this!!")
end

print(x)